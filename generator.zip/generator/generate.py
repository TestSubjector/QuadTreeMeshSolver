import argparse
from load import *
from boundary import *
from interior import *
from balance import *
from wall import *
from outer import *
from progress import *
from logger import *

def main():
    
    # Command Line Arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("-n","--neighbour",const=str, nargs="?")
    parser.add_argument("-w","--wall",const=str, nargs="?")
    args = parser.parse_args()
    print("Loading Data")
    
    # Opening the Neighbourhood file
    file1 = open(args.neighbour or "neighbour.txt","r")
    data = file1.read()
    file1.close()
    data = data.replace("\t"," ")
    data = data.split("\n")
    data.pop(0) # Pops the first blank line

    file2 = open(args.wall or "airfoil_160.txt","r")
    geometrydata = file2.read()
    geometrydata = geometrydata.split("\n")
    
    print("Loaded Data")
    silentRemove("log.txt")
    wallpoints = []

    hashtable,wallpointsdata,globaldata = loadWall(geometrydata)
    wallpoints.append(wallpointsdata)
    hashtable,globaldata = loadInterior(data,hashtable,globaldata,len(hashtable))
    globaldata = cleanNeighbours(globaldata)
    hashtable,globaldata = detectOuter(hashtable, globaldata)

    printL("***********************************")
    printL("Checking for Non Aerodynamic points")
    printL("***********************************")

    for index,item in enumerate(hashtable[1:]):
        printProgressBar(index,len(hashtable[1:])-1, prefix = 'Progress:', suffix = 'Complete', length = 50)
        if(getFlag(index,globaldata)==1):
            nonAeroCheck(index,globaldata,wallpoints)

    printL("***********************************")

    for index,item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            printPosDeltaConditions(index,globaldata,hashtable,15)

    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==0):
            printWallConditionValue(index,globaldata,hashtable)
            printWallConditionValue(index,globaldata,hashtable)
            printWallConditionValue(index,globaldata,hashtable)

    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==2):
            printOuterConditionValue(index,globaldata,hashtable)
            printOuterConditionValue(index,globaldata,hashtable)
            printOuterConditionValue(index,globaldata,hashtable)

    printL("***********************************")
    printL("Setting Pre Flags for Interior Points")
    printL("***********************************")

    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            globaldata = setPosDeltaFlags(index,globaldata,hashtable,50) #Threshold for Flag 3 - 6

    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            conditionValueFixForYPos(index,globaldata,hashtable,15,wallpoints)
    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            conditionValueFixForYNeg(index,globaldata,hashtable,15,wallpoints)
    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            conditionValueFixForXPos(index,globaldata,hashtable,15,wallpoints)
    for index, item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            conditionValueFixForXNeg(index,globaldata,hashtable,15,wallpoints)

    printL("****************************************")
    printL("Printing Delta Conditions for Interior Points")
    printL("****************************************")

    for index,item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            printPosDeltaConditions(index,globaldata,hashtable,15)

    printL("****************************************")
    printL("Printing Neighbour Conditions for Interior Points")
    printL("****************************************")

    for index,item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            nbhs = len(getNeighbours(index,globaldata))
            if(nbhs < 6):
                print("Warning",index,"has neighbours less than 6")
                print("It has",nbhs,"neighbours only")
                writeLog(["Warning",index,"has neighbours less than 6"])
                writeLog(["It has",nbhs,"neighbours only"])
            

    printL("****************************************")
    printL("Printing Delta Neighbour Conditions for Interior Points")
    printL("****************************************")
    
    for index,item in enumerate(hashtable[1:]):
        if(getFlag(index,globaldata)==1):
            printPosDeltaPointConditions(index,globaldata,hashtable,3)

    printL("****************************************")

    globaldata = cleanNeighbours(globaldata)
    globaldata = generateReplacement(hashtable,globaldata)

    with open("preprocessorfile.txt", "w") as text_file:
        for item1 in globaldata:
            text_file.writelines(["%s " % item for item in item1])
            text_file.writelines("\n")

if __name__ == "__main__":
    main()